import { redirect } from 'next/navigation'
import { createClient } from '@/lib/supabase/server'
import { ReceiptDetail } from '@/components/receipt-detail'

export default async function ReceiptDetailPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) redirect('/login')

  const { data: profile } = await supabase
    .from('profiles')
    .select('role')
    .eq('id', user.id)
    .single()

  if (!profile) redirect('/login')

  const { data: receipt } = await supabase
    .from('receipts')
    .select(`
      *,
      account_titles(name),
      tax_categories(name),
      payment_methods(name),
      profiles!receipts_created_by_fkey(display_name)
    `)
    .eq('id', id)
    .single()

  if (!receipt) redirect('/receipts')

  return (
    <div className="container max-w-2xl mx-auto p-4">
      <ReceiptDetail receipt={receipt} profile={profile} />
    </div>
  )
}
