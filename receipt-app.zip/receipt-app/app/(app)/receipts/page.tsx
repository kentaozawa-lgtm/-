import { createClient } from '@/lib/supabase/server'
import { ReceiptsList } from '@/components/receipts-list'

export default async function ReceiptsPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) return null

  const { data: profile } = await supabase
    .from('profiles')
    .select('*, organizations(*)')
    .eq('id', user.id)
    .single()

  if (!profile) return null

  return (
    <div className="container max-w-6xl mx-auto p-4">
      <ReceiptsList profile={profile} />
    </div>
  )
}
