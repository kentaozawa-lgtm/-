'use client'

import { useState, useRef } from 'react'
import { useRouter } from 'next/navigation'
import { Camera, Upload, AlertCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { useToast } from '@/components/ui/use-toast'
import { createClient } from '@/lib/supabase/client'
import { compressImage } from '@/lib/gemini'
import Link from 'next/link'

export default function ScanPage() {
  const [capturing, setCapturing] = useState(false)
  const [preview, setPreview] = useState<string | null>(null)
  const [uploading, setUploading] = useState(false)
  const [capturedFile, setCapturedFile] = useState<File | null>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const router = useRouter()
  const { toast } = useToast()
  const supabase = createClient()

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
      })
      streamRef.current = stream
      if (videoRef.current) {
        videoRef.current.srcObject = stream
      }
      setCapturing(true)
    } catch (error) {
      toast({
        title: 'カメラエラー',
        description: 'カメラの利用を許可してください',
        variant: 'destructive',
      })
    }
  }

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop())
      streamRef.current = null
    }
    setCapturing(false)
  }

  const capturePhoto = () => {
    if (!videoRef.current) return

    const canvas = document.createElement('canvas')
    canvas.width = videoRef.current.videoWidth
    canvas.height = videoRef.current.videoHeight
    const ctx = canvas.getContext('2d')!
    ctx.drawImage(videoRef.current, 0, 0)

    canvas.toBlob((blob) => {
      if (blob) {
        const file = new File([blob], 'receipt.jpg', { type: 'image/jpeg' })
        setCapturedFile(file)
        setPreview(URL.createObjectURL(blob))
        stopCamera()
      }
    }, 'image/jpeg')
  }

  const retake = () => {
    setPreview(null)
    setCapturedFile(null)
    startCamera()
  }

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setCapturedFile(file)
      setPreview(URL.createObjectURL(file))
    }
  }

  const uploadAndAnalyze = async () => {
    if (!capturedFile) return

    setUploading(true)

    try {
      // 画像を圧縮
      const { blob, base64 } = await compressImage(capturedFile)

      // Supabase Storageにアップロード
      const fileName = `${Date.now()}-${capturedFile.name}`
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('receipts')
        .upload(fileName, blob)

      if (uploadError) throw uploadError

      // 公開URLを取得
      const {
        data: { publicUrl },
      } = supabase.storage.from('receipts').getPublicUrl(fileName)

      // APIに解析リクエスト
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: base64,
          mimeType: 'image/jpeg',
          imageUrl: publicUrl,
        }),
      })

      if (!response.ok) {
        throw new Error('解析に失敗しました')
      }

      const { receiptId } = await response.json()

      toast({
        title: '解析完了',
        description: '内容を確認してください',
      })

      router.push(`/scan/review?id=${receiptId}`)
    } catch (error) {
      console.error('Upload error:', error)
      toast({
        title: 'エラー',
        description: 'アップロードに失敗しました。電波状況をご確認ください',
        variant: 'destructive',
      })
    } finally {
      setUploading(false)
    }
  }

  return (
    <div className="container max-w-2xl mx-auto p-4 space-y-4">
      <h1 className="text-2xl font-bold">領収書を撮影</h1>

      <Card>
        <CardContent className="p-6 space-y-4">
          {!capturing && !preview && (
            <>
              <Button
                onClick={startCamera}
                size="lg"
                className="w-full h-16 text-lg"
              >
                <Camera className="mr-2 h-6 w-6" />
                カメラを起動して撮影
              </Button>

              <div className="text-center text-sm text-muted-foreground">
                または
              </div>

              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                onChange={handleFileSelect}
                className="hidden"
              />
              <Button
                onClick={() => fileInputRef.current?.click()}
                variant="outline"
                size="lg"
                className="w-full h-16 text-lg"
              >
                <Upload className="mr-2 h-6 w-6" />
                画像を選ぶ（アルバムから）
              </Button>

              <div className="flex items-start gap-2 p-3 bg-blue-50 rounded-md">
                <AlertCircle className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
                <p className="text-sm text-blue-900">
                  文字がはっきり写るように撮影してください
                </p>
              </div>

              <RejectedReceiptsLink />
            </>
          )}

          {capturing && (
            <div className="space-y-4">
              <div className="camera-preview">
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex gap-2">
                <Button onClick={stopCamera} variant="outline" className="flex-1">
                  キャンセル
                </Button>
                <Button onClick={capturePhoto} className="flex-1">
                  撮影
                </Button>
              </div>
            </div>
          )}

          {preview && (
            <div className="space-y-4">
              <div className="camera-preview">
                <img
                  src={preview}
                  alt="プレビュー"
                  className="w-full h-full object-cover rounded-lg"
                />
              </div>
              <div className="flex gap-2">
                <Button
                  onClick={retake}
                  variant="outline"
                  className="flex-1"
                  disabled={uploading}
                >
                  撮り直す
                </Button>
                <Button
                  onClick={uploadAndAnalyze}
                  className="flex-1"
                  disabled={uploading}
                >
                  {uploading ? '処理中...' : 'この写真で進む'}
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

function RejectedReceiptsLink() {
  const supabase = createClient()
  const [rejectedCount, setRejectedCount] = useState<number>(0)

  // 差し戻し件数を取得
  useState(() => {
    const fetchRejectedCount = async () => {
      const { count } = await supabase
        .from('receipts')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'rejected')

      if (count !== null) {
        setRejectedCount(count)
      }
    }
    fetchRejectedCount()
  })

  if (rejectedCount === 0) return null

  return (
    <Link href="/receipts?status=rejected">
      <div className="p-3 bg-red-50 rounded-md border border-red-200 hover:bg-red-100 transition-colors">
        <p className="text-sm font-medium text-red-900">
          修正してください：{rejectedCount}件
        </p>
      </div>
    </Link>
  )
}
