'use client'

import { useState, useEffect, Suspense } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Card, CardContent } from '@/components/ui/card'
import { useToast } from '@/components/ui/use-toast'
import { createClient } from '@/lib/supabase/client'
import { Loader2 } from 'lucide-react'

function ReviewPageContent() {
  const searchParams = useSearchParams()
  const receiptId = searchParams.get('id')
  const router = useRouter()
  const { toast } = useToast()
  const supabase = createClient()

  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [receipt, setReceipt] = useState<any>(null)
  const [formData, setFormData] = useState({
    receipt_date: '',
    vendor: '',
    amount: '',
    account_title_id: '',
    tax_category_id: '',
    payment_method_id: '',
    invoice_number: '',
    tax_rate: '',
    memo: '',
  })

  const [masters, setMasters] = useState<{
    accountTitles: any[]
    taxCategories: any[]
    paymentMethods: any[]
  }>({
    accountTitles: [],
    taxCategories: [],
    paymentMethods: [],
  })

  useEffect(() => {
    if (!receiptId) return
    loadData()
  }, [receiptId])

  const loadData = async () => {
    try {
      const { data: receiptData } = await supabase
        .from('receipts')
        .select('*')
        .eq('id', receiptId)
        .single()

      if (!receiptData) return

      const { data: profile } = await supabase
        .from('profiles')
        .select('organization_id')
        .eq('id', receiptData.created_by)
        .single()

      const [accountTitles, taxCategories, paymentMethods] = await Promise.all([
        supabase
          .from('account_titles')
          .select('*')
          .eq('organization_id', profile?.organization_id)
          .eq('is_active', true),
        supabase
          .from('tax_categories')
          .select('*')
          .eq('organization_id', profile?.organization_id)
          .eq('is_active', true),
        supabase
          .from('payment_methods')
          .select('*')
          .eq('organization_id', profile?.organization_id)
          .eq('is_active', true),
      ])

      setReceipt(receiptData)
      setMasters({
        accountTitles: accountTitles.data || [],
        taxCategories: taxCategories.data || [],
        paymentMethods: paymentMethods.data || [],
      })

      // AIの候補から最も信頼度の高いものを選択
      const aiData = receiptData.ai_raw_data as any
      setFormData({
        receipt_date: receiptData.receipt_date,
        vendor: receiptData.vendor || '',
        amount: receiptData.amount.toString(),
        account_title_id: '',
        tax_category_id: '',
        payment_method_id: '',
        invoice_number: receiptData.invoice_number || '',
        tax_rate: receiptData.tax_rate?.toString() || '',
        memo: '',
      })

      setLoading(false)
    } catch (error) {
      console.error(error)
      toast({
        title: 'エラー',
        description: 'データの読み込みに失敗しました',
        variant: 'destructive',
      })
    }
  }

  const handleSave = async () => {
    if (!formData.receipt_date || !formData.amount) {
      toast({
        title: '入力エラー',
        description: '日付と金額を入力してください',
        variant: 'destructive',
      })
      return
    }

    setSaving(true)

    try {
      const { error } = await supabase
        .from('receipts')
        .update({
          receipt_date: formData.receipt_date,
          vendor: formData.vendor,
          amount: parseFloat(formData.amount),
          account_title_id: formData.account_title_id || null,
          tax_category_id: formData.tax_category_id || null,
          payment_method_id: formData.payment_method_id || null,
          invoice_number: formData.invoice_number,
          tax_rate: formData.tax_rate ? parseFloat(formData.tax_rate) : null,
          memo: formData.memo,
        })
        .eq('id', receiptId)

      if (error) throw error

      toast({
        title: '保存しました',
      })

      router.push(`/receipts/${receiptId}`)
    } catch (error) {
      console.error(error)
      toast({
        title: 'エラー',
        description: '保存できませんでした',
        variant: 'destructive',
      })
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <div className="container max-w-2xl mx-auto p-4 flex items-center justify-center min-h-[50vh]">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    )
  }

  return (
    <div className="container max-w-2xl mx-auto p-4 space-y-4">
      <h1 className="text-2xl font-bold">解析結果の確認</h1>

      {receipt && (
        <Card>
          <CardContent className="p-6 space-y-4">
            {/* 画像プレビュー */}
            <div>
              <img
                src={receipt.image_url}
                alt="領収書"
                className="w-full rounded-lg border"
              />
            </div>

            {/* フォーム */}
            <div className="space-y-4">
              <div>
                <Label htmlFor="date">日付 *</Label>
                <Input
                  id="date"
                  type="date"
                  value={formData.receipt_date}
                  onChange={(e) =>
                    setFormData({ ...formData, receipt_date: e.target.value })
                  }
                />
              </div>

              <div>
                <Label htmlFor="amount">金額 *</Label>
                <Input
                  id="amount"
                  type="number"
                  value={formData.amount}
                  onChange={(e) =>
                    setFormData({ ...formData, amount: e.target.value })
                  }
                  placeholder="0"
                />
              </div>

              <div>
                <Label htmlFor="vendor">取引先（店名）</Label>
                <Input
                  id="vendor"
                  value={formData.vendor}
                  onChange={(e) =>
                    setFormData({ ...formData, vendor: e.target.value })
                  }
                />
              </div>

              <div>
                <Label htmlFor="account">勘定科目</Label>
                <Select
                  value={formData.account_title_id}
                  onValueChange={(value) =>
                    setFormData({ ...formData, account_title_id: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="選択してください" />
                  </SelectTrigger>
                  <SelectContent>
                    {masters.accountTitles.map((item) => (
                      <SelectItem key={item.id} value={item.id}>
                        {item.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="tax">税区分</Label>
                <Select
                  value={formData.tax_category_id}
                  onValueChange={(value) =>
                    setFormData({ ...formData, tax_category_id: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="選択してください" />
                  </SelectTrigger>
                  <SelectContent>
                    {masters.taxCategories.map((item) => (
                      <SelectItem key={item.id} value={item.id}>
                        {item.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="payment">支払方法</Label>
                <Select
                  value={formData.payment_method_id}
                  onValueChange={(value) =>
                    setFormData({ ...formData, payment_method_id: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="選択してください" />
                  </SelectTrigger>
                  <SelectContent>
                    {masters.paymentMethods.map((item) => (
                      <SelectItem key={item.id} value={item.id}>
                        {item.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="invoice">インボイス番号</Label>
                <Input
                  id="invoice"
                  value={formData.invoice_number}
                  onChange={(e) =>
                    setFormData({ ...formData, invoice_number: e.target.value })
                  }
                  placeholder="T1234567890123"
                />
              </div>

              <div>
                <Label htmlFor="memo">メモ</Label>
                <Input
                  id="memo"
                  value={formData.memo}
                  onChange={(e) =>
                    setFormData({ ...formData, memo: e.target.value })
                  }
                />
              </div>
            </div>

            <div className="flex gap-2 pt-4">
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => router.push('/scan')}
                disabled={saving}
              >
                撮り直す
              </Button>
              <Button
                className="flex-1"
                onClick={handleSave}
                disabled={saving}
              >
                {saving ? '保存中...' : '下書き保存'}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

export default function ReviewPage() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <ReviewPageContent />
    </Suspense>
  )
}
