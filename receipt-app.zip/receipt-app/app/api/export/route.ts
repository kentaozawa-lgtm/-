import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()

    // 認証確認
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: '認証が必要です' }, { status: 401 })
    }

    // 管理者チェック
    const { data: profile } = await supabase
      .from('profiles')
      .select('role, organization_id')
      .eq('id', user.id)
      .single()

    if (!profile || profile.role !== 'admin') {
      return NextResponse.json({ error: '権限がありません' }, { status: 403 })
    }

    const { month } = await request.json()

    // 承認済みの領収書を取得
    const { data: receipts } = await supabase
      .from('receipts')
      .select(`
        *,
        account_titles(name),
        tax_categories(name),
        payment_methods(name, account_name)
      `)
      .eq('organization_id', profile.organization_id)
      .eq('status', 'approved')
      .gte('receipt_date', `${month}-01`)
      .lte('receipt_date', `${month}-31`)
      .order('receipt_date', { ascending: true })

    if (!receipts || receipts.length === 0) {
      return NextResponse.json(
        { error: '出力対象のデータがありません' },
        { status: 400 }
      )
    }

    // CSV生成
    const headers = [
      '発生日',
      '収支区分',
      '勘定科目',
      '金額',
      '税区分',
      '決済口座',
      '取引先',
      '備考',
    ]

    const rows = receipts.map((receipt) => {
      const accountName = receipt.account_titles?.name || ''
      const taxName = receipt.tax_categories?.name || ''
      const paymentAccount = receipt.payment_methods?.account_name || ''
      const vendor = receipt.vendor || ''
      const invoiceInfo = receipt.invoice_number
        ? `適格番号:${receipt.invoice_number}`
        : ''
      const taxRateInfo = receipt.tax_rate ? ` / 税率:${receipt.tax_rate}%` : ''
      const memoInfo = receipt.memo ? ` / ${receipt.memo}` : ''
      const remarks = `${invoiceInfo}${taxRateInfo}${memoInfo}`

      return [
        receipt.receipt_date,
        '支出',
        accountName,
        receipt.amount,
        taxName,
        paymentAccount,
        vendor,
        remarks,
      ]
    })

    const csvContent = [
      headers.join(','),
      ...rows.map((row) =>
        row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(',')
      ),
    ].join('\n')

    // BOMを追加（Excel対応）
    const bom = '\uFEFF'
    const csvWithBom = bom + csvContent

    // 領収書を「出力済み」に更新
    const receiptIds = receipts.map((r) => r.id)
    await supabase
      .from('receipts')
      .update({ status: 'exported' })
      .in('id', receiptIds)

    // 出力履歴を記録
    await supabase.from('export_history').insert({
      organization_id: profile.organization_id,
      export_month: month,
      exported_by: user.id,
      receipt_count: receipts.length,
      file_url: '', // 実運用ではStorageに保存
    })

    return new NextResponse(csvWithBom, {
      headers: {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': `attachment; filename="receipts-${month}.csv"`,
      },
    })
  } catch (error) {
    console.error('Export error:', error)
    return NextResponse.json(
      { error: 'CSV出力に失敗しました' },
      { status: 500 }
    )
  }
}
